package packt.taman.jfx8.ch4;

/**
 *
 * @author jpereda
 */
public interface Platform {
    
    void callNumber(String number);
    
}
